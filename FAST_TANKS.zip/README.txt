FAST_TANKS is a 2 person tank battle game, written for the Nintendo
Entertainment System (NES) platform. It is written in 6502 assembly
language and is compiled using dasm.exe the 8-bit macro assembler.
It has been tested on FCEUX a NES emulator. YY-CHR was used
for sprite editing and creation.